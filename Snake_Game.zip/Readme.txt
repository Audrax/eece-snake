When the BASYS 3 board is connected to a monitor via the VGA port, a snake head (white dot) should be drawn on the monitor. It should be controllable by using the push buttons on the board.

How to Operate the Snake Game

- Button T18 should move the snake head up
- Button U17 should move the snake head down
- Button W19 should move the snake head left
- Button T17 should move the snake head right
When the BASYS 3 board is connected to a monitor via the VGA port, various colors should be drawn on the monitor based off the position of the switches on the board.

How to Operate the VGA Tester

- Switch V17 toggles the RED signal
- Switch V16 toggles the BLUE signal
- Switch W16 toggles the GREEN signal